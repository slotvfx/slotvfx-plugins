---
name: motion-sequence
description: Plan and author SlotVFX videos, trailers, LinkedIn/social posts and multi-part showcases as Timeline Director sequences of separate shot clips (clip bars, Spine animation bars, music, beats, titles, Blends, Speed keys); decide one clip vs a sequence; use Scene Animator and recorder scenarios for event-driven flows.
---

For clips delivered to a game, use [animation review and budgets](../slot-vfx-motion-craft/references/animation-review.md) and `slotfx_review_animation`. Editor-only sequences/recordings have different delivery rules. Recording at 60 fps does not require 60 authored keys per second.

## One clip or a sequence

Decide this before creating anything. Ask: is it one moment, or a story made of several moments?

- **One clip**: one game event (big win, symbol win, transition, in-game logo reveal), parts locked to the same beats (impact, flash, shake and coins on one frame), anything that loops (idle, hold, anticipation), or a post that shows a single effect (record the clip for a few cycles).
- **Separate clips on a sequence**: separate shots that could be reordered, trimmed, sped up or dropped without touching their insides; music on the beat, title cards, Blends between shots or the same shot played twice; shots that are also game effects (the game keeps the clips, the video arranges them); a Spine character playing several animations in a row (Spine animation bars with mixes, where the connected sequence guide lists `spineBars`).
- **Scene Animator**: the game decides what plays next.

Videos, trailers, LinkedIn/social posts, multi-logo reels and spin → anticipation → win demo videos are sequences. Don't build several shots in one long clip unless they really are one continuous moment. Plan the shot list first, then follow [Plan shots, then assemble](references/timeline-director.md#plan-shots-then-assemble).

Inspect the scene, existing clips, state machine and any trailer document. Use a clip for one animation, Timeline Director for a fixed arrangement of clips (existing ones or shots built for it), Scene Animator for event-driven states, or a recorder scenario to demonstrate those events. When the connected `slotfx://authoring-guide/sequences` describes `media`, `blends` and `videoEdits`, Video edits are trailer sequences: loose video, images, text and sound go on a trailer sequence's media rows, and older Video edits convert to sequences when opened. Do not convert every sequence into a logo reveal or rebuild the editor externally.

Read [Timeline Director and Speed-key workflows](references/timeline-director.md) for arrangements, recorded showcases, music/beat grids, title cards, Blends, slow motion and game-export boundaries. Read the live resources `slotfx://authoring-guide/sequences`, `slotfx://authoring-guide/slow-motion` and `slotfx://authoring-guide/recording`. These describe the 0.9.80 tool surface; resolve actual clip and asset IDs before authoring.

Use `get_trailer_document`, `prepare_trailer_media` and `edit_trailer_document` only after reading their current action schemas, revision requirements and asset support. With the merged editor they accept a trailer sequence ID and edit its media rows (an alias kept for one release); prefer `slotfx_edit_sequence` for moving, trimming, splitting and blending. Preserve existing transitions, clips, audio and track membership. Time units differ between seconds, frame-grid keys and recorder frames; use explicit exact-time or frame semantics and read representative values back.

For states, inspect trigger declarations and parameter schemas. In 0.9.80 a saved recorder scenario plays its state clips independently of the editing clip; no neutral base clip is required. `matchScenario` resolves scenario timing; it is not the same as repeating a looping clip. Distinguish entry, hold and exit behavior for variable durations; a single clip can suffice, with separate stages only when their control is needed.

Read [workflow routes, motion and recording checks](references/workflows.md); use relevant bundled logo-reveal, spin-showcase or showcase-video detail when available, and [motion craft](../slot-vfx-motion-craft/SKILL.md) to choose eases, springs, staggers and beats and write them as exact keys. Review entry, turning points, transitions and tail in SlotVFX itself. Activate the intended clip before playing it, focus the relevant result, and inspect editor state. For recording requested by the user, pass the exact timeline/scenario and per-job fps, dimensions and frame count. Poll lifecycleState rather than assuming a queued take completed. Preserve sound and validate its sync. Native title/callout recording does not establish game-runtime text/group-motion support. Return the editable sequence ready in SlotVFX and any explicitly requested verified media; expose editor-only bake/export steps clearly.

Use natural playback in the existing editor for motion review. Chat frame strips and recorded files are separate requested outputs or targeted diagnostics. Keep authored loop/duration and existing recorder settings intact when merely showing the sequence. Never expand an inspection-only tool policy.

If no `slotfx_` tools are available at all, SlotVFX isn't connected to Claude Code yet; say so plainly instead of attempting the work, and help the user connect it with [Connect SlotVFX](../slotvfx-mcp-authoring/references/connect-slotvfx.md).
