---
name: motion-sequence
description: Author SlotVFX Timeline Director sequences and trailers with clip bars, music, beats, titles, Blends and Speed keys; use Scene Animator and recorder scenarios for event-driven flows.
---

Inspect the scene, existing clips, state machine and any trailer document. Use a clip for one animation, Timeline Director for a fixed arrangement of existing clips, Scene Animator for event-driven states, or a recorder scenario to demonstrate those events. Trailer document tools are a separate editorial/media route. Do not convert every sequence into a logo reveal or rebuild the editor externally.

Read [Timeline Director and Speed-key workflows](references/timeline-director.md) for arrangements, recorded showcases, music/beat grids, title cards, Blends, slow motion and game-export boundaries. Read the live resources `slotfx://authoring-guide/sequences`, `slotfx://authoring-guide/slow-motion` and `slotfx://authoring-guide/recording`. These describe the 0.9.80 tool surface; resolve actual clip and asset IDs before authoring.

Use `get_trailer_document`, `prepare_trailer_media` and `edit_trailer_document` only after reading their current action schemas, revision requirements and asset support. Preserve existing transitions, clips, audio and track membership. Time units differ between seconds, frame-grid keys and recorder frames; use explicit exact-time or frame semantics and read representative values back.

For states, inspect trigger declarations and parameter schemas. In 0.9.80 a saved recorder scenario plays its state clips independently of the editing clip; no neutral base clip is required. `matchScenario` resolves scenario timing; it is not the same as repeating a looping clip. Distinguish entry, hold and exit behavior for variable durations; a single clip can suffice, with separate stages only when their control is needed.

Read [workflow routes, motion and recording checks](references/workflows.md); use relevant bundled logo-reveal, spin-showcase or showcase-video detail when available, and [motion craft](../slot-vfx-motion-craft/SKILL.md) to choose eases, springs, staggers and beats and write them as exact keys. Review entry, turning points, transitions and tail in SlotVFX itself. Activate the intended clip before playing it, focus the relevant result, and inspect editor state. For recording requested by the user, pass the exact timeline/scenario and per-job fps, dimensions and frame count. Poll lifecycleState rather than assuming a queued take completed. Preserve sound and validate its sync. Native title/callout recording does not establish game-runtime text/group-motion support. Return the editable sequence ready in SlotVFX and any explicitly requested verified media; expose editor-only bake/export steps clearly.

Use natural playback in the existing editor for motion review. Chat frame strips and recorded files are separate requested outputs or targeted diagnostics. Keep authored loop/duration and existing recorder settings intact when merely showing the sequence. Never expand an inspection-only tool policy.

If no `slotfx_` tools are available at all, SlotVFX isn't connected to Claude Code yet; say so plainly instead of attempting the work, and help the user connect it with [Connect SlotVFX](../slotvfx-mcp-authoring/references/connect-slotvfx.md).
